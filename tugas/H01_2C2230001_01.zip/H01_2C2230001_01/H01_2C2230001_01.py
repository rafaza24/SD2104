# Fungsi untuk menghitung keuntungan
def keuntungan(harga_dasar, harga_jual):
    return harga_jual - harga_dasar

# Input harga dasar dan harga jual untuk masing-masing barang
harga_dasar_A = int(input("Masukkan harga dasar barang A: "))
harga_jual_A = int(input("Masukkan harga jual barang A: "))

harga_dasar_B = int(input("Masukkan harga dasar barang B: "))
harga_jual_B = int(input("Masukkan harga jual barang B: "))

harga_dasar_C = int(input("Masukkan harga dasar barang C: "))
harga_jual_C = int(input("Masukkan harga jual barang C: "))

# Menghitung keuntungan untuk setiap barang
untung_A = keuntungan(harga_dasar_A, harga_jual_A)
untung_B = keuntungan(harga_dasar_B, harga_jual_B)
untung_C = keuntungan(harga_dasar_C, harga_jual_C)

# Menentukan barang dengan keuntungan terbesar
if untung_A > untung_B and untung_A > untung_C:
    barang_terbaik = "A"
elif untung_B > untung_A and untung_B > untung_C:
    barang_terbaik = "B"
else:
    barang_terbaik = "C"

# Menampilkan hasil
print(f"Barang yang harus ditawarkan adalah barang {barang_terbaik}")